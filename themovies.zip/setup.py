from wsgiref.simple_server import make_server
from pyramid.config import Configurator
from pyramid.view import view_config
from pyramid.authorization import ACLAuthorizationPolicy
from pyramid.config import Configurator
from pyramid.authorization import ACLAuthorizationPolicy
import pymysql
import jwt
import json
import datetime
import requests

# Koneksi ke database MySQL

connection = pymysql.connect(
    host='localhost',
    user='root',
    password='',
    db='pyramid-themovies',
    charset='utf8mb4',
    cursorclass=pymysql.cursors.DictCursor
)
    
def authenticate_user(login, password):
    # Note the below will not work, its just an example of returning a user
    # object back to the JWT creation.
    # login_query = session.query(User).\
    #     filter(User.login == login).\
    #     filter(User.password == password).first()
    with connection.cursor() as cursor:
        sql = "SELECT * FROM users WHERE username=%s AND password=%s"
        cursor.execute(sql, (login, password))
        login_query = cursor.fetchone()

    if login_query:
        user_dict = {
            'userid': login_query.id,
            'user_name': login_query.user_name,
            'roles': login_query.roles
        }
        # An example of login_query.roles would be a list
        # print(login_query.roles)
        # ['admin', 'reports']
        return user_dict
    else:
        # If we end up here, no logins have been found
        return None

@view_config(route_name='login', renderer='json')
def login(request):
    '''Create a login view
    '''
    login = request.POST['login']
    password = request.POST['password']
    print(login, password)
    with connection.cursor() as cursor:
        sql = "SELECT * FROM users WHERE username=%s AND password=%s"
        cursor.execute(sql, (login, password))
        user = cursor.fetchone()
    if user:
        cookie_value = request.create_jwt_token(
                user['id'],
                userName=user['username']
            )
        cookie = request.response.set_cookie('pyramid', cookie_value, max_age=7200, httponly=True)
        return {
            'result': 'ok',
            'token': cookie_value
        }
    else:
        return {
            'result': 'error',
            'token': None
        }

@view_config(route_name='hello', renderer="json")
def hello(request):
    authorization_header = request.cookies.get('pyramid')
    if authorization_header:
        # token = authorization_header.split('Bearer ')[1]
        # decoded_user = jwt.decode(authorization_header, request.registry.settings['jwt.secret'], algorithms=['HS256'])
        # print(decoded_user)
        user_id = 1
        
        # Retrieve the refresh token from the database based on the user's ID
        with connection.cursor() as cursor:
            sql = "SELECT refresh_token FROM tokens WHERE user_id=%s"
            cursor.execute(sql, (user_id,))
            result = cursor.fetchone()

        if result:
            refresh_token = result['refresh_token']
            # Verify the refresh token (you should use a different secret for refresh tokens)
            decoded_refresh_token = jwt.decode(refresh_token, 'refresh_secret', algorithms=['HS256'])
            print(decoded_refresh_token)
            if decoded_refresh_token:
                # If refresh token is valid, return the response
                return {'greet': 'Welcome'}
            else:
                request.response.status = 401  # Unauthorized
                return {'greet': 'Unauthorized', 'name': '', 'error': 'Invalid refresh token'}
        else:
            request.response.status = 401  # Unauthorized
            return {'greet': 'Unauthorized', 'name': '', 'error': 'Refresh token not found'}
    
    return {
        'result': 'ok',
        'message': 'Hello world!'
    }

if __name__ == "__main__":
    with Configurator() as config:
        config.add_route('login', '/login')
        config.add_route('hello', '/welcome')
        config.scan()
        config.set_authorization_policy(ACLAuthorizationPolicy())
        config.add_static_view(name='static', path='static')
        config.include('pyramid_jwt')
        config.set_jwt_cookie_authentication_policy(
            'secret', reissue_time=7200
        )
        
        app = config.make_wsgi_app()
    # Menjalankan aplikasi pada server lokal
    server = make_server('0.0.0.0', 6543, app)
    server.serve_forever()